<!DOCTYPE html > 
<html >
<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style.css">

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 456px;
  max-height: 330px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: black;
  font-size: 40px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #643877;
  text-align: center;
  cursor: pointer;
  width: 80%;
  font-size: 25px;
}



button:hover, a:hover {
  opacity: 0.5;
}
</style>
</head>
<body>

<?php
include("conexao.php");
session_start();

$_SESSION['nome1'];

   $cpf = $_SESSION['nome1'];



//$sql = "UPDATE empresas SET nomeempresa='$nomeempresa' WHERE cnpj= '$cnpj'";

try {
    $dbh = new PDO("mysql:host=$servidor;dbname=$dbname", $usuario, $senha, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $dbh->prepare("update autonomo set nomeempresa=:nomeempresa, email=:email, telefone=:telefone, celular=:celular, endereco=:endereco, numero=:numero, 
    
    bairro=:bairro, instagram=:instagram, facebook=:facebook, obs=:obs, delivery=:delivery, drive_thru=:drive_thru, agendamento=:agendamento, esta_aberto=:esta_aberto,
    
    hr_aberto=:hr_aberto, hr_fechado=:hr_fechado, zap=:zap where cpf= '$cpf'");
 

  $v1 = strtoupper ( $_POST['nomeempresa']);
  $v2 = strtoupper ($_POST['endereco']);
  $v3 = strtoupper($_POST['bairro']);
  $v4 = strtoupper($_POST['delivery']);
  $v5 = strtoupper($_POST['drive_thru']);
  $v6 = strtoupper($_POST['agendamento']);
  $v7 = strtoupper($_POST['esta_aberto']);
  $v8 = strtoupper($_POST['zap']);

    $stmt->bindParam(":nomeempresa", $v1);
    $stmt->bindParam(":email", ($_POST['email']));
    $stmt->bindParam(":telefone", $_POST['telefone']);
    $stmt->bindParam(":celular", $_POST['celular']);
    $stmt->bindParam(":endereco", $v2);
    $stmt->bindParam(":numero", $_POST['numero']);
    $stmt->bindParam(":bairro", $v3 );
    $stmt->bindParam(":instagram", ($_POST['instagram']));
    $stmt->bindParam(":facebook", ($_POST['facebook']));
    $stmt->bindParam(":obs",  ($_POST['obs']));
    $stmt->bindParam(":delivery", $v4);
    $stmt->bindParam(":drive_thru", $v5 );
    $stmt->bindParam(":agendamento", $v6);
    $stmt->bindParam(":esta_aberto", $v7);
    $stmt->bindParam(":hr_aberto",  ($_POST['hr_aberto']));
    $stmt->bindParam(":hr_fechado",  ($_POST['hr_fechado']));
    $stmt->bindParam(":zap",$v8 );
    if($stmt->execute())
    echo "";

} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
 
?>

<div class="card">
  <img src="img/logo2.jpg" class="img">
  <h1></h1>
  <p class="title"><b>Cadastro Atualizado!</b></p>
 
  <form action="index.php">
  <p><button >Voltar</button></p>
</form>
</div>

</body>
</html>
