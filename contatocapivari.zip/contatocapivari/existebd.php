<?php
   include("conexao.php");
   session_start();
   
  
   
   $_SESSION['nome'];

   $cnpj = $_SESSION['nome'];



   
      
      $myusername = mysqli_real_escape_string($conn,$cnpj);
     
      
      $sql = "SELECT cnpj FROM empresas WHERE cnpj = '$myusername' ";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      
		
      if($count == 1) {
         
         header('Location: cadastrese2.php');
         
         
      }else {
        header('Location: cadastrese.php');
         
      }
?>
