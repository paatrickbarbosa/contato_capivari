<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head> <title>Contato Capivari</title>
            <meta charset="utf-8">
            <meta http-equiv=”Content-Type” content=”text/html; charset=utf-8″>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="css/navbar.css">
            <link rel="stylesheet" href="css/pesquisa.css">

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="index.php">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php">Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php">Sugestões</a>
  <a href="pesquisa.php"  class="active">Procurar</a>
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script><br>


<form method="post" action="pesquisa.php"><center>
<input type="text" class="cx" placeholder=" Pesquisar" name="nome">
<input type="submit" class="botao1" name="buscar" value="Procurar">
</form><br><div style="overflow-x:auto;"></center><br>
<?php
include "conexao.php";

$post = "%".$_POST["nome"]."%";

$fe = "SELECT nomeempresa, telefone, celular from empresas WHERE nomeempresa like '$post'
        UNION all
        SELECT nomeempresa, telefone, celular FROM autonomo where nomeempresa like '$post'
        order by nomeempresa asc";


$todos = "SELECT empresas.nomeempresa, empresas.telefone, empresas.celular FROM empresas
          UNION all
          SELECT autonomo.nomeempresa, autonomo.telefone, autonomo.celular from autonomo
          ORDER BY
          nomeempresa ASC";



try {
    $dbh = new PDO("mysql:host=$servidor;dbname=$dbname", $usuario, $senha, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if( !empty($_POST) ) {
        $sth = $dbh->prepare($fe);
        $sth->bindParam(1, $post);


    } else {
        $sth = $dbh->prepare($todos);
    }
    $sth->execute();
    $result = $sth->fetchAll(PDO::FETCH_ASSOC);
    echo "<center><table class='table' border=1 cellpading=0 cellspacing=0><tr>";?>

    <tr>
    <th >Empresas</th>
    <th>Telefone</th>
    <th>Celular</th>
  	</tr>

    <?php echo "</tr>";
    foreach($result as $row) {
        echo "<tr>";
        foreach($row as $id => $value){
            echo "<td>$value</td>";
        }
        
    }
    echo "</table>";
    $dbh = null;
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}

?></center>
</div>


</body>
</html>
