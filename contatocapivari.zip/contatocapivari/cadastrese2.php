<?php



include("conexao.php");
   
session_start();
   
  
   
$_SESSION['nome'];

$cnpj = $_SESSION['nome'];
      
    //$myusername = mysqli_real_escape_string($conn,$cnpj);
     
      
  //$sql = "SELECT cnpj FROM empresas WHERE cnpj = '$myusername' ";


//$result = "SELECT * FROM empresas WHERE cnpj =  '44.723.674/0001-90' ";


$result = "SELECT * FROM empresas WHERE cnpj =  '$cnpj' ";
$resultado = mysqli_query($conn, $result);

$row = mysqli_fetch_assoc($resultado) ;



?>



<!DOCTYPE html>
<html>

<head lang="pt-br"><meta charset="utf-8">
	  
	  <title>Contato Capivari</title>
            
            
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="css/navbar.css">
            <link rel="stylesheet" href="css/titulo.css">
            <link rel="stylesheet" href="css/cadastrese.css">
            <link rel="stylesheet" href="css/select.css">

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      </head>

    <body>

              <!--NAVBAR-->
              <div class="topnav" id="myTopnav">
  <a href="index.php" class="active">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php">Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php">Sugestões</a>
  <a href="pesquisa.php" >Procurar</a>
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
              <!--NAVBAR-->
            
                <form action="update.php" method="post">

                        <br><center><div class="titulo">
                              <h1>Cadastre-se</h1> 
                        </div> </center><br>
                
                <hr> 
                
                
                
                <div class="margem">

                    <label for="nomeempresa"><b>Nome da Empresa</b></label><br>
                        <input  type="text" maxlength="30" placeholder="Nome da Empresa" name="nomeempresa" value="<?php echo utf8_encode ($row['nomeempresa']);?>"> <br>
                    
                    <label for="email"><b>Email</b></label><br>
                        <input type="text" placeholder="Email da empresa" name="email" maxlength="41" value="<?php echo $row['email'];?>" ><br>

                    <label for="telefone"><b>Telefone</b></label><br>
                        <input type="text" class="form-control phone-ddd-mask" placeholder="Telefone Fixo ou celular" name="telefone" value="<?php echo $row['telefone'];?>"><br>

                    <label for="celular"><b>Whatsapp</b></label><br>
                        <input type="text" class="form-control cel-sp-mask" placeholder="Whatsapp da empresa" name="celular" value="<?php echo $row['celular'];?>"><br>
                    
                    <label for="endereco"><b>Endereço</b></label><br>
                        <input type="text" placeholder="RUA " name="endereco"  maxlength="35" autocomplete="off" value="<?php echo $row['endereco'];?>"><br>
                    
                    <label for="numero"><b>Número</b></label>
                        <input type="text"  class="form-control" placeholder="NÚMERO" name="numero" data-mask="0000-X" maxlength="6" value="<?php echo $row['numero'];?>">
                    
                    <label for="bairro"><b>Bairro</b></label><br>
                        <input type="text" placeholder="Bairro" name="bairro" maxlength="30" value="<?php echo $row['bairro'];?>"><br>
                    
                    <label for="instagram"><b>Instagram</b></label><br>
                        <input type="text" placeholder="https://www.instagram.com/instagramdaempresa" name="instagram" value="<?php echo $row['instagram'];?>"><br>
                    
                    <label for="facebook"><b>Facebook</b></label><br>
                        <input type="text" placeholder="https://pt-br.facebook.com/facebookdaempresa" name="facebook" value="<?php echo $row['facebook'];?>"><br>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                        <label for="obs"><b>Observação</b></label><br>
                        <input type="text" placeholder="Observação (Campo não obrigatório)" name="obs" value="<?php echo $row['obs'];?>"><br>

                        <label for="hora"><b>Horário de Atendimento</b></label><br><br>
                        
                        <label for="hr_aberto">Abre:</label>
                          <input type="time" class="form-control " data-mask="00:00" name="hr_aberto" value="<?php echo $row['hr_aberto'];?>">
                          <label for="hr_fechado">Fecha:</label>
                          <input type="time" class="form-control " data-mask="00:00" name="hr_fechado" value="<?php echo $row['hr_fechado'];?>"><br>

                        


              
              
              
              
              
              
              
              
                          <br> <table>
                      <tr>
                        <th>Tipo de Atendimento</th>
                        
                        
                      </tr>
                      <tr>
                        <td>Delivery</td>
                        <td><input type="text"  name="delivery" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" value="<?php echo $row['delivery'];?>"></td>
                        
                      </tr>
                      <tr>
                        <td>Drive- Thru</td>
                        <td><input type="text"  name="drive_thru" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" value="<?php echo $row['drive_thru'];?>"></td>
                        
                      </tr>
                      
                      <tr>
                        <td>Agendamento</td>
                        <td><input type="text"  name="agendamento" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" value="<?php echo $row['agendamento'];?>"></td>
                        
                      </tr>
                      <tr>
                        <td>Estabelecimento Aberto</td>
                        <td><input type="text"  name="esta_aberto" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" value="<?php echo $row['esta_aberto'];?>"></td>
                        
                      </tr>
                      <tr>
                        <td>Via Whatsapp</td>
                        <td><input type="text"  name="zap" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" value="<?php echo $row['zap'];?>"></td>
                        
                      </tr>
                    </table>
             
            </div>

             
                      
                <hr>
                
                    
                <center><button type="submit" class="registerbtn"><b>Salvar/Alterar</b></button></center>
              </div>
              </div>
            </form>
 <!-- Atente-se para a ordem: primeiro jquery, depois locastyle, depois o JS do Bootstrap. -->
 <script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>

      </body>
</html>