<!DOCTYPE html> 
<html >
<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style.css">

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 456px;
  max-height: 330px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: black;
  font-size: 40px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #643877;
  text-align: center;
  cursor: pointer;
  width: 80%;
  font-size: 25px;
}



button:hover, a:hover {
  opacity: 0.5;
}
</style>
</head>
<body>
<?php


$c = $_POST['cpf'];


function validaCPF($cpf){

	
	$cpf = preg_replace('/[^0-9]/','',$cpf);

	$digitoA = 0;
	$digitoB = 0;

	for($i = 0, $x = 10; $i <=8; $i++, $x--){
		$digitoA += $cpf[$i] * $x;
	}
	
	for($i = 0, $x = 11; $i <= 9; $i++, $x--){
		
		if(str_repeat($i, 11) == $cpf){
		return false;
	}

	$digitoB += $cpf[$i] * $x;

}

$somaA = (($digitoA%11) < 2 ) ? 0 : 11- ($digitoA%11);
$somaB = (($digitoB%11) < 2 ) ? 0 : 11- ($digitoB%11);

if($somaA != $cpf[9] || $somaB != $cpf[10]){
	return false;
}else{
	return true;
}
}

if(validaCPF($c)){
	header('Location: existe_bd_pf.php');
}else{
	echo "<br>";
}

session_start();
                
$_SESSION['nome1'] = $_POST['cpf'];

$a = $_POST['cpf'];
?>


<div class="card">
  <img src="img/logo2.jpg" class="img">
  <h1></h1>
  <p class="title"><b>CPF INVÁLIDO!</b></p>
 
  <form action="precad_pf.php">
  <p><button >Voltar</button></p>
</form>
</div>
</body>
</html>