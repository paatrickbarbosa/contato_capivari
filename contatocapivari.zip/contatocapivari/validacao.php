<!DOCTYPE html>
<html >
<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
</head>
<body>
<?php 
    session_start();
   require_once('conecta.php');
   
   
   
    $cnpj = $_POST['cnpj'];
    
    $sqlstring = " select cnpj from empresas where cnpj = '$cnpj'";
    $info = mysqli_query($mysqli, $sqlstring);
    if (!$info) { die('<b>Query Invalida: </b>' . mysqli_error($mysqli)); }
    
    $registro = mysqli_num_rows($info);	
    
    if($registro!=$info){
       
        $_SESSION['nao_autenticado'] = true;
        header('Location: cadastrese.php');
      
    }else{
        $_SESSION['cnpj'] = $cnpj;
        header('location: index.php');
        
        exit();
        
    }
    ?>
</body>
</html>    
    
    