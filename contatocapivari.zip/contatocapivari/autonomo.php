<!DOCTYPE html>
<html lang="pt-br">
      <head><meta charset="utf-8">
            
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="css/style.css">
            <link rel="stylesheet" href="css/navbar.css">
            <link rel="stylesheet" href="css/titulo.css">

<title>Contato Capivari</title>
      </head>
      <body>

      <div class="topnav" id="myTopnav">
  <a href="index.php" class="active">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php">Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php">Sugestões</a>
  <a href="pesquisa.php" >Procurar</a>
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
     
                <br><center><div class="titulo">
                  
                  <div class="container1">
                    <h1>Contatos</h1> 
                    
                  </div>
                </div></center><br>

                <br>

        
        
                    <?php

                          $t = "SELECT * from empresas WHERE ramo = '9'
                          UNION all
                          SELECT * FROM autonomo where ramo = '9'
                          order by nomeempresa asc";
                                          //Variaveis de conexao com o BD
                include "conexao.php";

                $empresas = filter_input(INPUT_POST, 'empresas', FILTER_SANITIZE_STRING);
                      $result_usuario = ($t);
                      $resultado_usuario = mysqli_query($conn, $result_usuario);
                      while($row_usuario = mysqli_fetch_assoc($resultado_usuario)){?>
                                            
                                            
                              <div class="row">
                                            <div class="column123">
                                            <div class="column">
                                            <div class="card">
                                            <div class="container">
                                            <div class="parag">
                                          
                                            
                                            <p><?php
                    
                    echo "<h3  class='centro'><i><u>"  . utf8_encode ($row_usuario['nomeempresa']) . "</i></u></h3>";
                    echo "<b >E-mail: </b><br>" . $row_usuario['email'] . "<br>";
                    echo "<b>Telefone:</b> <br>" . $row_usuario['telefone'] . "<br>";
                    echo "<b>Horario de Atendimento: </b><br> " .  $row_usuario['hr_aberto'] . " hs até " .  $row_usuario['hr_fechado'] ." hs<br>";
                  // echo "<form onsubmit='myFunction()'><input type='submit' value='endereço' ></form>"
                  echo "<br><b><u>Tipo de Atendimento:</u> <br> </b><br>" ;
                  

                  
                  $v4 = $row_usuario['delivery'];
                  $v5 = $row_usuario['drive_thru'];
                  $v6 = $row_usuario['agendamento'];
                  $v7 = $row_usuario['esta_aberto'];
                  $v8 = $row_usuario['zap'];

                  if($v4 == 'S'){
                    $d = ' <i>  Delivery,  </i>';
                    echo $d;
                  }
                  else{
                    echo"";
                  }
                  
                  if($v5 == 'S'){
                    $d_t = '<i>  Drive-Thru, </i> ';
                    echo $d_t;
                  }
                  else{
                    echo"";
                  }
                  
                  if($v6 == 'S'){
                    $agenda = '<i>  Agendamento, </i> ';
                    echo $agenda;
                  }
                  else{
                    echo"";
                  }
                  

                  if( $v7 == 'S'){
                    $e_a = '<i>  Estabelecimento Aberto,</i>'   ;
                    echo  $e_a  ;
                  }
                  else{
                    echo"";
                  }
                  if($v8 == 'S'){
                    $s_w = '<i>Via Whatsapp.</i>'   ;
                    echo  $s_w . "<br>" ;
                  }
                  else{
                    echo"<br>" ;
                  }

                    
                    ?>
                    
                 <?php
                      $end = $row_usuario['endereco'];
                      $num = $row_usuario['numero'];
                      $cid = "Capivari/SP";


                   
                      echo "<br><a  target='_blank'href='https://www.instagram.com/". $row_usuario['instagram'] . "'><center> <i class='fa fa-instagram'></i></a> " ;
                      echo "<a  target='_blank'href= 'https://www.facebook.com/". $row_usuario['facebook']."'><i class='fa fa-facebook'></i></a> ";
                      echo "<a target='_blank' href='http://maps.google.com/?daddr=" . $end ."," . $num . "," . $cid . "'><i class='fa fa-map-marker'></i></a></center>";
                      echo "<a target='_blank' href='https://api.whatsapp.com/send?phone=55" . $row_usuario['celular'] . "'><center> <img src='img/whatsapp.png'  > </a></center>";
                      
                        
                        
                      
                  
                        ?>
                       <!-- <script>
function myFunction() {
alert("<?php

//$a = "aaa";
//echo $a; ?>");
}
</script>-->

</div>
</div>
</div>
</div>
</div>

<?php } ?>          </p>  


                <div style="overflow-x:auto;">
                
                </div>



      </body>
</html>