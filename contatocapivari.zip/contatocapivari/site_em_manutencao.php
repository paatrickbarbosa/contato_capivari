<!DOCTYPE html > 
<html >
<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style.css">

            
            <style>
                .card {
                  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                  max-width: 456px;
                  max-height: 330px;
                  margin: auto;
                  text-align: center;
                  font-family: arial;
                }
                
                .title {
                  color: black;
                  font-size: 40px;
                }
                
                button {
                  border: none;
                  outline: 0;
                  display: inline-block;
                  padding: 8px;
                  color: white;
                  background-color: #643877;
                  text-align: center;
                  cursor: pointer;
                  width: 80%;
                  font-size: 25px;
                }
                
                
                
                button:hover, a:hover {
                  opacity: 0.5;
                }
                </style>

      </head>
      <body>

        <div class="card">
            <img src="img/logo2.jpg" class="img">
            <h1></h1>
            <p class="title"><b> Em Manutenção</b></p>
           
            <form action="https://prefeituracapivari.sp.gov.br/">
            <p><button >Voltar</button></p>
          </form>
          </div>
          </body>
          </html>