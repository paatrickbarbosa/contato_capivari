<?php
session_start();

$a = $_SESSION['nome'];


?>

<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html >
<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style.css">

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 456px;
  max-height: 330px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: black;
  font-size: 40px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #643877;
  text-align: center;
  cursor: pointer;
  width: 80%;
  font-size: 25px;
}



button:hover, a:hover {
  opacity: 0.5;
}
</style>
</head>
<body>
<?php
    include("conexao.php");

    try {
       // $mysqli=new mysqli($servidor,$usuario,$senha,$bancodedados);
	    $dbh = new PDO("mysql:host=$servidor;dbname=$dbname", $usuario, $senha, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
	    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        
		



	    $stmt = $dbh->prepare("insert into empresas (nomeempresa,email,telefone,celular,endereco,obs,delivery, ramo, agendamento, drive_thru, esta_aberto, numero, bairro, instagram, facebook, cnpj, hr_aberto,hr_fechado, zap ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
        //$stmt->bindParam(1, $idempresas);
        $stmt->bindParam(1, $nomeempresa);
	      $stmt->bindParam(2, $email);
	      $stmt->bindParam(3, $telefone);
        $stmt->bindParam(4, $celular);
        $stmt->bindParam(5, $endereco);
        $stmt->bindParam(6, $obs);
        $stmt->bindParam(7, $delivery);
        $stmt->bindParam(8, $ramo);
        $stmt->bindParam(9, $agendamento);
        $stmt->bindParam(10, $drive_thru);
        $stmt->bindParam(11, $esta_aberto);
        $stmt->bindParam(12, $numero);
        $stmt->bindParam(13, $bairro);
        $stmt->bindParam(14, $instagram);
        $stmt->bindParam(15, $facebook);
        $stmt->bindParam(16, $cnpj);
        $stmt->bindParam(17, $hr_aberto);
        $stmt->bindParam(18, $hr_fechado);
        $stmt->bindParam(19, $zap);

        




	      $nomeempresa = strtoupper ($_POST["nomeempresa"]);
	      $email = strtolower($_POST["email"]);
	      $telefone = $_POST["telefone"];
        $celular = $_POST["celular"];
        $endereco = strtoupper ( $_POST["endereco"]);
        $obs = strtoupper ($_POST["obs"]);
        $delivery = strtoupper($_POST["delivery"]);
        $ramo = $_POST["ramo"];
        $agendamento = strtoupper($_POST["agendamento"]);
        $drive_thru = strtoupper($_POST["drive_thru"]);
        $esta_aberto = strtoupper($_POST["esta_aberto"]);
        $numero = $_POST["numero"];
        $bairro = strtoupper ($_POST["bairro"]);
        $instagram = strtolower($_POST["instagram"]);
        $facebook =strtolower( $_POST["facebook"]);
        $cnpj = $a;
        $hr_aberto = $_POST["hr_aberto"];
        $hr_fechado = $_POST["hr_fechado"];
        $zap = strtoupper($_POST["zap"]);
        if($stmt->execute())
        

        echo ""; //nao apagar - exibia ramo


        //INSERT INTO ramo_x_empresa (r_idramo, e_idempresa) VALUES ($idaramo,$ramo);
        
    } catch (PDOException $e) {
	    print "Error!: " . $e->getMessage() . "<br/>";
	    die();
	}
	
	
//$_SESSION['cnpj1'] = $cnpj;

?>
<div class="card">
  <img src="img/logo2.jpg" class="img">
  <h1></h1>
  <p class="title"><b>Cadastro Realizado!</b></p>
 
  <form action="index.php">
  <p><button >Voltar</button></p>
</form>
</div>

<!--<br><a href="index.php"></a>-->
</body>
</html>
