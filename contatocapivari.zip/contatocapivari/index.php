<!DOCTYPE html>
<html>

<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
<meta http-equiv=”Content-Type” content=”text/html; charset=utf-8″>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/navbar.css">
<link rel="stylesheet" href="css/titulo.css">
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/cadastrese.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>

<body>
   
      

<div class="topnav" id="myTopnav">
  <a href="index.php" class="active">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php">Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php">Sugestões</a>
  <a href="pesquisa.php" >Procurar</a>
  
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

<br><center><div class="titulo">
  
  
    <h1>Categorias</h1> 
    
  </div>
</div></center><br>

<br>

<div class="row">
  <div class="column">
    
    <div class="card"  >
        
      <img src="img/alimento.jpg" class="img"  style="width:100%" >
      <div class="container">
        <h2 >Alimentos</h2>
        <form action="alimento.php">
            <p><button   class="button">Contatos</button></p>
        </form>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="img/beleza.jpeg" class="img" style="width:100%"  >
      <div class="container">
        <h2 >Beleza</h2>
        <form action="beleza.php">
          <p><button   class="button">Contatos</button></p>
        </form>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="img/escola.jpeg"  class="img" style="width:100%" >
      <div class="container">
        <h2 >Escolas</h2>
        <form action="escola.php">
          <p><button   class="button">Contatos</button></p>
        </form>  
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="img/mecanica.jpeg"  class="img" style="width:100%" >
      <div class="container">
        <h2 >Mecânica</h2>
        <form action="mecanica.php">
          <p><button   class="button">Contatos</button></p>
      </form>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="img/petshop.jpg"  class="img" style="width:100%">
      <div class="container">
        <h2 >PetShop</h2>
        <form action="petshop.php">
          <p><button   class="button">Contatos</button></p>
      </form> 
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="img/saude.jpg"  class="img" style="width:100%"  >
      <div class="container">
        <h2 >Saúde</h2>
          <form action="saude.php">
            <p><button   class="button">Contatos</button></p>
    </form> 
      </div>
    </div>
  </div>


  <div class="column">
    <div class="card">
      <img src="img/tecnologia.jpeg" class="img" style="width:100%" >
      <div class="container">
        <h2 >Tecnologia</h2>
        <form action="tecnologia.php">
          <p><button  class="button">Contatos</button></p>
        </form>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img src="img/vestuario.jpg" class="img" style="width:100%" >
      <div class="container">
        <h2 >Vestuário</h2>
        <form action="vestuario.php">
         <p><button   class="button">Contatos</button></p>
    </form>
      </div>
    </div>
  </div>

  

  

  <div class="column">
    <div class="card">
      <img src="img/autonomo.jpeg"  class="img" style="width:100%" >
      <div class="container">
        <h2 >Outros</h2>
        <form action="autonomo.php">
          <p><button   class="button">Contatos</button></p>
        </form>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="img/equipe.jpg"  class="img" style="width:100%" >
      <div class="container">
        <h2 >Todos</h2>
        <form action="todos.php">
          <p><button   class="button">Contatos</button></p>
      </form>
      </div>
    </div>
  </div>

</body>
</html>
