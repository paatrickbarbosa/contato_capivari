<?php
session_start();
?>
<!DOCTYPE html>
<html >
<head lang="pt-br">
	  
	  <title>Contato Capivari</title>
            <meta charset="utf-8">
            <meta http-equiv=”Content-Type” content=”text/html; charset=utf-8″>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="css/navbar.css">
            <link rel="stylesheet" href="css/titulo.css">
            <link rel="stylesheet" href="css/cadastrese.css">
            <link rel="stylesheet" href="css/select.css">
            <link rel="stylesheet" href="css/notificacao.css">

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      </head>

    <body>

              <!--NAVBAR-->
              <div class="topnav" id="myTopnav">
  <a href="index.php" >Home</a>
  
  <div class="dropdown">
    <button class="dropbtn"class="active">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php" >Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php">Sugestões</a>
  <a href="pesquisa.php" >Procurar</a>
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
              <!--NAVBAR-->
            
                <!--<form action="processa.php" method="post">-->

                        <br><center><div class="titulo">
                              <h1>Pessoa Física</h1> 
                        </div> </center><br>
                
                <hr><center> <div>
                
                

                </label>
                </div><br></center>
                
                <div class="margem">
                
                        
                        <form action="validar_pf.php" method="POST">
                   <br><label for="cpf"><b>CPF</b></label><br>
                        <input  type="text" class="form-control" placeholder="CPF" name="cpf" required  data-mask="000.000.000-00" maxlength="14" autocomplete="off"><br>


                        
                    
					
                             
                     </div>                <hr>
                
                   
                <center><button type="submit" class="registerbtn"><b>Consultar</b></button></center>
              </div>
              
            </form>
           <!-- Atente-se para a ordem: primeiro jquery, depois locastyle, depois o JS do Bootstrap. -->
<script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script> 
      </body>
</html>
