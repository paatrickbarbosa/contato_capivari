<!DOCTYPE html>
<html >
<head lang="pt-br"><meta charset="utf-8">
	  
	  <title>Contato Capivari</title>
            

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/navbar.css">
<link rel="stylesheet" href="css/titulo.css">
<link rel="stylesheet" href="css/cadastrese.css">
<link rel="stylesheet" href="css/sugestao.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


        <body>

        
<div class="topnav" id="myTopnav">
  <a href="index.php" >Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php">Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php" class="active">Sugestões</a>
  <a href="pesquisa.php" >Procurar</a>
  
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
            

            <br><center><div class="titulo">
  
  
    <h1>Sugestões</h1> 
    
  
</div></center><br>




<div class="card">
  <img src="img/logo2.jpg" class="img" style="width:100%"><br><br>
  
  
  <h3>Para alteraçoes, sugestões ou criticas, entre em contato conosco através do email ou telegram.</h3>
  
  
   <a target="_blank" href="https://t.me/pmc_comercio"><i class="fa fa-telegram"></i></a>
 <br> <p><center><a href="mailto:informatica@capivari.sp.gov.br"><button class="btn1">Email</button></center></p></a>
</div>
   
  </div>
  
</div>

                   
          </body>
</html>