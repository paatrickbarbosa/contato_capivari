<?php
              
               session_start();

               
              
               ?>

<!DOCTYPE html>
<html>

      <head lang="pt-br"><meta charset="utf-8">
	  
	  <title>Contato Capivari</title>
            
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="css/navbar.css">
            <link rel="stylesheet" href="css/titulo.css">
            <link rel="stylesheet" href="css/cadastrese.css">
            
            <link rel="stylesheet" href="css/select1.css">

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

            
      </head>

    <body>

              <!--NAVBAR-->
              <div class="topnav" id="myTopnav">
  <a href="index.php" >Home</a>
  
  <div class="dropdown">
  <button class="dropbtn"class="active">Cadastre-se
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="precad_pf.php" >Pessoa Física</a>
      <a href="precad.php">Pessoa Jurídica</a>
     
    </div>
    </div> 
  <a href="sugestao.php">Sugestões</a>
  <a href="pesquisa.php" >Procurar</a>
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
              <!--NAVBAR-->
            
                <form action="processa_pf.php" method="post">

                        <br><center><div class="titulo">
                              <h1>Pessoa Física</h1> 
                        </div> </center><br>
                
                <hr><center> <div>
                
                <label for="ramo" class="b"><b>Qual seu ramo?</b></label>  <br> <br>
              
                <select class="a" id="ramo" name="ramo"required>
                    <option style= "border-radius:20px;"class="b" value="">Ramo </style></ option>
                    <option class="a" value="1">Alimento</option>
                    <option class="a"value="2">Beleza</option>
                    <option class="a"value="3">Escola</option>
                    <option class="a"value="4">Mecanica</option>
                    <option class="a"value="5">PetShop</option>
                    <option class="a"value="6">Saúde</option>
                    <option class="a"value="7">Tecnologia</option>
                    <option class="a"value="8">Vestuario</option>
                    <option class="a"value="9">Outros</option>
                    </div>
                   
                  </select>




           

                </label>
                </div><br></center>
                
              
   

                
                


                <div class="margem">

                    <label for="nomeempresa"><b>Nome Fantasia</b></label><br>
                        <input  type="text"   placeholder="Nome Fantasia" name="nomeempresa" maxlength="30" required   ><br>
                    <label for="cpf"><b>CPF</b></label><br>
                        <input  type="text"   placeholder="CPF"  name="cpf" disabled  value="<?php echo $_SESSION['nome1'];?>" ><br>
                    <label for="email"><b>Email</b></label><br>
                        <input type="text" placeholder="Email da empresa" maxlength="41" name="email" ><br>
                    <label for="telefone"><b>Telefone</b></label><br>
                        <input type="text"  class="form-control phone-ddd-mask" placeholder="Telefone " name="telefone" ><br>
                    <label for="celular"><b>Whatsapp</b></label><br>
                        <input type="text" class="form-control cel-sp-mask" placeholder="Whatsapp da empresa" name="celular" ><br>
                    <label for="endereco"><b>Endereço</b></label><br>
                        <input type="text"  placeholder="RUA  "  maxlength="35" name="endereco" required autocomplete="off"><br>
                    <label for="numero"><b>Número</b></label>
                        <input type="text"  class="form-control" placeholder="NÚMERO"   name="numero" required data-mask="0000-X" maxlength="6" >
                    <label for="bairro"><b>Bairro</b></label><br>
                        <input type="text" placeholder="Bairro" name="bairro" maxlength="30" required><br>
                    <label for="instagram"><b>Instagram</b></label><br>
                        <input type="text" placeholder="Id instagram" name="instagram" ><br>
                    <label for="facebook"><b>Facebook</b></label><br>
                        <input type="text" placeholder="Id facebook" name="facebook" ><br>
                    
                    
                    
                        
                    
                    
                    
                    
                    
                        <label for="obs"><b>Observação</b></label><br>
                        <input type="text" placeholder="Observação (Campo não obrigatório)" name="obs"><br>

            

                        <label for="hora"><b>Horário de Atendimento</b></label><br><br>
                        
                        <label for="hr_aberto">Abre:</label>
                          <input type="time" class="form-control " data-mask="00:00" name="hr_aberto" required>
                          <label for="hr_fechado">Fecha:</label>
                          <input type="time" class="form-control " data-mask="00:00" name="hr_fechado" required><br>

                                            <br> <table>
                      <tr>
                        <th>Tipo de Atendimento</th>
                        
                        
                      </tr>
                      <tr>
                        <td>Delivery</td>
                        <td><input type="text"  name="delivery" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" required></td>
                        
                      </tr>
                      <tr>
                        <td>Drive- Thru</td>
                        <td><input type="text"  name="drive_thru" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" required></td>
                        
                      </tr>
                      
                      <tr>
                        <td>Agendamento</td>
                        <td><input type="text"  name="agendamento" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" required></td>
                        
                      </tr>
                      <tr>
                        <td>Estabelecimento Aberto</td>
                        <td><input type="text"  name="esta_aberto" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" required></td>
                        
                      </tr>
                      <tr>
                        <td>Via Whatsapp</td>
                        <td><input type="text"  name="zap" pattern="([n,s])" placeholder="S / N" maxlength="1" title="s ou n" required></td>
                        
                      </tr>
                    </table>
            </div>

              <!--<br>Delivery: <input type="radio" name="delivery" value="SIM"> SIM <input type="radio" name="delivery" value="Não"> NÃO
                      -->
                <hr>
                
                <input type="hidden" name="acao" value="enviar"/>        
                <center><button type="submit" class="registerbtn"><b>Registrar</b></button></center>
              </div>
              </div>
            </form>



              <!-- Atente-se para a ordem: primeiro jquery, depois locastyle, depois o JS do Bootstrap. -->
<script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
      </body>
</html>