<?php
$servidor = "localhost";
$usuario = "virus";
$senha = "convid19";
$dbname = "covid";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);