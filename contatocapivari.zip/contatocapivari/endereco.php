<?php

include("conexao.php");
   
session_start();
   
$_SESSION['nome'];
$cnpj = $_SESSION['nome'];
$result = "SELECT * FROM empresas WHERE cnpj =  '$cnpj' ";
$resultado = mysqli_query($conn, $result);

$row = mysqli_fetch_assoc($resultado) ;

?>




       <!DOCTYPE html>
<html lang="en">
<head>
  <title>Contato Capivari</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/modal.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>      
            <div class="container">
  
  
  <div class="row mb-4">
    <div class="col text-center">
      
      <a href="#" class="btn btn-lg btn-success" data-toggle="modal" data-target="#basicModal">Endereço</a>
    </div>
  </div>
  
  

<!-- basic modal -->
<div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"><b><?php echo $row['nomeempresa'];?></b></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="margem">

                    
<label for="endereco"><b>Endereço</b></label><br>
    <input type="text" placeholder="RUA " name="endereco" value="<?php echo $row['endereco'];?>"><br>
<label for="numero"><b>Número</b></label><br>
    <input type="text" placeholder="NÚMERO" name="numero" value="<?php echo $row['numero'];?>"><br>
<label for="bairro"><b>Bairro</b></label><br>
    <input type="text" placeholder="Bairro" name="bairro" value="<?php echo $row['bairro'];?>"><br>

</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
        
      </div>
    </div>
  </div>
</div>


                </body>
                </html>