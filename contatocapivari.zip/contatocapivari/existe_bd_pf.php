<?php
   include("conexao.php");
   session_start();
   
  
   
   $_SESSION['nome1'];

   $cpf = $_SESSION['nome1'];



   
      
      $myusername = mysqli_real_escape_string($conn,$cpf);
     
      
      $sql = "SELECT cpf FROM autonomo WHERE cpf = '$myusername' ";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      
		
      if($count == 1) {
         
         header('Location: cad_pf2.php');
         
         
      }else {
        header('Location: cad_pf.php');
         
      }
?>